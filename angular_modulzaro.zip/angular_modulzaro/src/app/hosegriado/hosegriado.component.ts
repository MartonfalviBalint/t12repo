import { Component } from '@angular/core';

@Component({
  selector: 'app-hosegriado',
  templateUrl: './hosegriado.component.html',
  styleUrls: ['./hosegriado.component.css']
})
export class HosegriadoComponent {

  kozepHomerseklet1: number = 30;
  kozepHomerseklet2: number = 31;
  kozepHomerseklet3: number = 32;
  eredmenyek: string[] = [];
  riadoSzint: string = '';

  aktualisRiadoSzint(): string {
    const atlagHomerseklet = (this.kozepHomerseklet1 + this.kozepHomerseklet2 + this.kozepHomerseklet3) / 3;
    let riadoSzint = '';

    if (atlagHomerseklet < 25) {
      riadoSzint = '0. szintű';
    } else if (atlagHomerseklet >= 25 && atlagHomerseklet < 27) {
      riadoSzint = '1. szintű';
    } else if (atlagHomerseklet >= 27 && atlagHomerseklet < 30) {
      riadoSzint = '2. szintű';
    } else {
      riadoSzint = '3. szintű';
    }

    return riadoSzint;
  }

  EredmenyMentes(): void {
    if (this.kozepHomerseklet1 !== null && this.kozepHomerseklet2 !== null && this.kozepHomerseklet3 !== null) {
      const atlagHomerseklet = (this.kozepHomerseklet1 + this.kozepHomerseklet2 + this.kozepHomerseklet3) / 3;
      const riadoSzint = this.aktualisRiadoSzint();
  
      this.eredmenyek.push(`${this.kozepHomerseklet1}, ${this.kozepHomerseklet2} és ${this.kozepHomerseklet3} esetén ${riadoSzint} hőségriadó volt elrendelve `);
  
      this.kozepHomerseklet1 = 30;
      this.kozepHomerseklet2 = 31;
      this.kozepHomerseklet3 = 32;
      this.riadoSzint = riadoSzint;
    }
  }
}


